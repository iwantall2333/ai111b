package com.example.ai_hw2

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Text
import java.io.IOException
import java.util.*
import kotlin.concurrent.thread


class MainActivity : AppCompatActivity() {
    var client = OkHttpClient()

    lateinit var btn_ai: ImageButton
    lateinit var btn_record: ImageButton
    lateinit var show_text:TextView
    lateinit var textToSpeech: TextToSpeech
    var user_message: String = "今天幾號"


    val handler = Handler()
    var isHandlerRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_ai = findViewById(R.id.btn_ai)
        btn_record = findViewById(R.id.btn_record)
        show_text = findViewById(R.id.textView)



        //animation_aiButton
        val animator_ai = ObjectAnimator.ofFloat(btn_ai, "translationY", 0f, 50f)
        animator_ai.setDuration(1000); // 设置动画时长，单位为毫秒
        animator_ai.setRepeatCount(ObjectAnimator.INFINITE); // 设置动画重复次数，这里是无限循环
        animator_ai.setRepeatMode(ObjectAnimator.REVERSE); // 设置动画循环模式，这里是正序和倒序
        animator_ai.start(); // 启动动画
        val imageIds = intArrayOf(R.drawable.ai1, R.drawable.ai3)
        var index = 0
        val runnable = object : Runnable {
            override fun run() {
                // 显示下一张图片
                index = (index + 1) % imageIds.size
                btn_ai.setImageResource(imageIds[index])

                handler.postDelayed(this, 3000)
            }
        }
        startHandler(runnable)
        val message:String = "你好啊"

        btn_record.setOnClickListener {
            speak()
            /*
            版权声明：語音轉文字的code为CSDN博主「心平气和呀」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
            原文链接：https://blog.csdn.net/weixin_45562000/article/details/106241636
            * */
            show_text.setText("")

        }

    }
    private fun speak() {
        val mIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        mIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "输入语音")

        try {
            startActivityForResult(mIntent, 100)
        }
        catch (e: Exception){
            Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            100 -> {
                if(resultCode == Activity.RESULT_OK && null != data){
                    val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    user_message = result?.get(0) ?: "no"
                    show_text.text = result?.get(0) ?: "no"
                    receiveResponse(user_message.toString()){response->
                        runOnUiThread{
                            show_text.text = response
                        }
                    }
                }
            }
        }
    }

    fun receiveResponse(question: String,callback:(String) -> Unit){
        val apiKey = ""
        val url = "https://api.openai.com/v1/engines/text-davinci-003/completions"

        val requestBody="""
            {
              "prompt": "(妳是我溫柔的女朋友，妳對我這個男友說話，每一句話都要說寶貝，而且妳覺得男友我超帥，且都會在50個字以內說完話)$question",
              "max_tokens": 200,
              "temperature": 0.3
            }
        """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type"," application/json")
            .addHeader("Authorization"," Bearer $apiKey")
            .post(requestBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()

        client.newCall(request).enqueue(object : Callback{
            override fun onFailure(call: Call, e: IOException) {
                Log.e("error","API failed",e)
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (body != null) {
                    Log.v("data",body)
                }
                else{
                    Log.v("data","empty")
                }
                    val jsonObject = JSONObject(body)
                    val jsonArray:JSONArray = jsonObject.getJSONArray("choices")
                    val textResult = jsonArray.getJSONObject(0).getString("text")
                    callback(textResult)
                    textToSpeech = TextToSpeech(applicationContext,TextToSpeech.OnInitListener {
                    if(it == TextToSpeech.SUCCESS){
                        textToSpeech.language = Locale.CHINESE
                        textToSpeech.setSpeechRate(1.0f)
                        textToSpeech.speak(show_text.text.toString(),TextToSpeech.QUEUE_ADD,null)
                    }
                })
                }


        })

    }



    // 启动Runnable对象，开始循环切换图片
    fun startHandler(runnable:Runnable) {
        if (!isHandlerRunning) {
            isHandlerRunning = true
            handler.postDelayed(runnable, 3000)
        }
    }

    // 停止Handler对象，停止循环切换图片
    fun stopHandler() {
        isHandlerRunning = false
        handler.removeCallbacksAndMessages(null)
    }
}

